***********************************************************************************
Wojtyla 2013 - forked from el_draco OIP repository - July 2013
***********************************************************************************
OIPGUI.CPP:
#include <iostream>
contents input-output streaming

--variable cout = standard output
	print = cout << "a string"
	
--variable event.key.keysym.sym the code to compare which button on keyboard was released
	
***********************************************************************************